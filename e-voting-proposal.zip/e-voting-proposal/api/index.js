const express = require('express');
const mongoose = require('mongoose');
const sgMail = require('@sendgrid/mail');
const otpGenerator = require('otp-generator');
const dotenv = require('dotenv');

dotenv.config();
const app = express();
app.use(express.json());

// Set SendGrid API Key
sgMail.setApiKey(process.env.SENDGRID_API_KEY);

// MongoDB Connection
mongoose.connect('mongodb://127.0.0.1:27017/evoting')
    .then(() => console.log('Connected to MongoDB'))
    .catch(err => console.error('MongoDB connection error:', err));

// User Schema
const userSchema = new mongoose.Schema({
    name: String,
    dob: String,
    mobile: String,
    email: String,
    password: String,
    role: String,
    otp: String,
    otpExpires: Date
});
const User = mongoose.model('User', userSchema);

// Send OTP Email Function
const sendOTP = async (email, otp) => {
    const msg = {
        to: email,
        from: process.env.SENDER_EMAIL,
        subject: 'Your E-Voting OTP Code',
        text: `Your OTP code is ${otp}. It expires in 5 minutes.`,
        html: `<p>Your OTP code is <strong>${otp}</strong>. It expires in 5 minutes.</p>`
    };
    try {
        await sgMail.send(msg);
        console.log(`OTP sent to ${email}: ${otp}`);
        return { success: true, message: 'OTP sent' };
    } catch (error) {
        console.error('SendGrid Error:', error.response?.body || error);
        return { success: false, message: `Error sending OTP: ${error.message}` };
    }
};

// Test Email Endpoint (for debugging)
app.get('/test-email', async (req, res) => {
    const result = await sendOTP('test@example.com', '123456');
    res.json(result);
});

// Signup: Send OTP
app.post('/signup/send-otp', async (req, res) => {
    try {
        const { email } = req.body;
        console.log(`Signup OTP request for email: ${email}`);
        if (!email) return res.status(400).json({ success: false, message: 'Email is required' });

        const otp = otpGenerator.generate(6, { digits: true, upperCaseAlphabets: false, specialChars: false });
        const otpExpires = Date.now() + 5 * 60 * 1000; // 5 minutes

        // Check if user already exists
        const existingUser = await User.findOne({ email });
        if (existingUser) return res.status(400).json({ success: false, message: 'Email already registered' });

        // Temporarily store OTP
        await User.create({ email, otp, otpExpires });
        console.log(`Stored OTP for ${email}: ${otp}`);

        const emailResult = await sendOTP(email, otp);
        if (!emailResult.success) return res.status(500).json(emailResult);

        res.json({ success: true, message: 'OTP sent' });
    } catch (error) {
        console.error('Signup Send OTP Error:', error.stack);
        res.status(500).json({ success: false, message: 'Error occurred while sending OTP' });
    }
});

// Signup: Verify OTP and Complete Registration
app.post('/signup/verify-otp', async (req, res) => {
    try {
        const { email, otp, name, dob, mobile, password, role } = req.body;
        console.log(`Verifying OTP for email: ${email}, OTP: ${otp}`);
        if (!email || !otp) return res.status(400).json({ success: false, message: 'Email and OTP are required' });

        const user = await User.findOne({ email });
        if (!user) return res.status(400).json({ success: false, message: 'User not found' });
        if (user.otp !== otp) return res.status(400).json({ success: false, message: 'Invalid OTP' });
        if (Date.now() > user.otpExpires) return res.status(400).json({ success: false, message: 'OTP expired' });

        // Update user with full details
        user.name = name;
        user.dob = dob;
        user.mobile = mobile;
        user.password = password; // In production, hash this password!
        user.role = role;
        user.otp = undefined;
        user.otpExpires = undefined;
        await user.save();
        console.log(`User registered: ${email}, Role: ${role}`);

        res.json({ success: true, role });
    } catch (error) {
        console.error('Signup Verify OTP Error:', error.stack);
        res.status(500).json({ success: false, message: 'Error occurred during OTP verification' });
    }
});

// Login: Send OTP
app.post('/login/send-otp', async (req, res) => {
    try {
        const { mobileEmail, password } = req.body;
        console.log(`Login OTP request for: ${mobileEmail}`);
        if (!mobileEmail || !password) return res.status(400).json({ success: false, message: 'Mobile/Email and password are required' });

        const user = await User.findOne({
            $or: [{ mobile: mobileEmail }, { email: mobileEmail }],
            password // In production, compare hashed passwords!
        });
        if (!user) return res.status(400).json({ success: false, message: 'Invalid credentials' });

        const otp = otpGenerator.generate(6, { digits: true, upperCaseAlphabets: false, specialChars: false });
        const otpExpires = Date.now() + 5 * 60 * 1000; // 5 minutes

        user.otp = otp;
        user.otpExpires = otpExpires;
        await user.save();
        console.log(`Stored OTP for login ${user.email}: ${otp}`);

        const emailResult = await sendOTP(user.email, otp);
        if (!emailResult.success) return res.status(500).json(emailResult);

        res.json({ success: true, message: 'OTP sent' });
    } catch (error) {
        console.error('Login Send OTP Error:', error.stack);
        res.status(500).json({ success: false, message: 'Error occurred while sending OTP' });
    }
});

// Login: Verify OTP
app.post('/login/verify-otp', async (req, res) => {
    try {
        const { mobileEmail, otp } = req.body;
        console.log(`Verifying login OTP for: ${mobileEmail}, OTP: ${otp}`);
        if (!mobileEmail || !otp) return res.status(400).json({ success: false, message: 'Mobile/Email and OTP are required' });

        const user = await User.findOne({
            $or: [{ mobile: mobileEmail }, { email: mobileEmail }]
        });
        if (!user) return res.status(400).json({ success: false, message: 'User not found' });
        if (user.otp !== otp) return res.status(400).json({ success: false, message: 'Invalid OTP' });
        if (Date.now() > user.otpExpires) return res.status(400).json({ success: false, message: 'OTP expired' });

        user.otp = undefined;
        user.otpExpires = undefined;
        await user.save();

        res.json({ success: true, role: user.role });
    } catch (error) {
        console.error('Login Verify OTP Error:', error.stack);
        res.status(500).json({ success: false, message: 'Error occurred during OTP verification' });
    }
});

// Placeholder endpoints for events, voting, and results
app.post('/createEvent', async (req, res) => {
    res.json({ success: true, message: 'Event created' });
});
app.get('/event/:id', async (req, res) => {
    res.json({ success: true, event: { id: req.params.id, name: 'Sample Event' } });
});
app.post('/vote', async (req, res) => {
    res.json({ success: true, message: 'Vote recorded' });
});
app.get('/results/:eventId', async (req, res) => {
    res.json({ success: true, results: { eventId: req.params.eventId, votes: { Alice: 5, Bob: 3 } } });
});

const PORT = process.env.PORT || 5001;
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});