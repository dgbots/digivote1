async function handleSignup() {
    const name = document.getElementById('signup-name').value;
    const dob = document.getElementById('signup-dob').value;
    const mobile = document.getElementById('signup-mobile').value;
    const email = document.getElementById('signup-email').value;
    const password = document.getElementById('signup-password').value;
    const role = document.getElementById('signup-role').value;

    if (!name || !dob || !mobile || !email || !password || !role) {
        alert('Please fill in all fields.');
        return;
    }

    try {
        const response = await fetch('http://localhost:5000/signup', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name, dob, mobile, email, password, role })
        });
        const data = await response.json();
        if (data.success) {
            alert('Signup successful! Please check your email for OTP.');
        } else {
            alert('Signup failed: ' + data.message);
        }
    } catch (error) {
        console.error('Error:', error);
        alert('An error occurred during signup.');
    }
}

async function handleLogin() {
    const mobile = document.getElementById('login-mobile').value;
    const password = document.getElementById('login-password').value;
    const otp = document.getElementById('login-otp').value;

    if (!mobile || !password || !otp) {
        alert('Please fill in all fields.');
        return;
    }

    try {
        const response = await fetch('http://localhost:5000/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ mobile, password, otp })
        });
        const data = await response.json();
        if (data.success) {
            localStorage.setItem('userRole', data.role);
            alert('Login successful! Redirecting...');
            window.location.href = 'index.html';
        } else {
            alert('Login failed: ' + data.message);
        }
    } catch (error) {
        console.error('Error:', error);
        alert('An error occurred during login.');
    }
}

async function createEvent() {
    const name = document.getElementById('event-name').value;
    const candidates = document.getElementById('event-candidates').value.split('\n').filter(c => c.trim());
    const start = document.getElementById('event-start').value;
    const end = document.getElementById('event-end').value;

    if (!name || candidates.length === 0 || !start || !end) {
        alert('Please fill in all fields.');
        return;
    }

    try {
        const response = await fetch('http://localhost:5000/createEvent', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name, candidates, start, end })
        });
        const data = await response.json();
        if (data.success) {
            alert('Event created successfully!');
            const eventList = document.getElementById('event-list');
            const eventDiv = document.createElement('div');
            eventDiv.className = 'p-4 bg-gray-100 rounded-lg';
            eventDiv.innerHTML = `
                <h3 class="text-lg font-medium">${data.event.name}</h3>
                <p>Candidates: ${data.event.candidates.join(', ')}</p>
                <p>Start: ${new Date(data.event.start).toLocaleString()}</p>
                <p>End: ${new Date(data.event.end).toLocaleString()}</p>
                <a href="vote.html?eventId=${data.event._id}" class="text-indigo-600 hover:underline">Vote Now</a>
                <a href="results.html?eventId=${data.event._id}" class="ml-4 text-indigo-600 hover:underline">View Results</a>
            `;
            eventList.appendChild(eventDiv);
        } else {
            alert('Event creation failed: ' + data.message);
        }
    } catch (error) {
        console.error('Error:', error);
        alert('An error occurred while creating the event.');
    }
}

async function loadEventDetails(eventId) {
    try {
        const response = await fetch(`http://localhost:5000/event/${eventId}`);
        const data = await response.json();
        if (data.success) {
            const event = data.event;
            document.getElementById('event-title').textContent = `Vote: ${event.name}`;
            const candidatesList = document.getElementById('candidates-list');
            candidatesList.innerHTML = event.candidates.map((candidate, index) => `
                <div class="flex items-center space-x-3">
                    <input type="radio" name="candidate" id="candidate-${index}" value="${candidate}" class="h-5 w-5 text-indigo-600">
                    <label for="candidate-${index}" class="text-gray-700">${candidate}</label>
                </div>
            `).join('');
        } else {
            alert('Failed to load event: ' + data.message);
        }
    } catch (error) {
        console.error('Error:', error);
        alert('An error occurred while loading the event.');
    }
}

async function castVote() {
    const eventId = new URLSearchParams(window.location.search).get('eventId');
    const selectedCandidate = document.querySelector('input[name="candidate"]:checked')?.value;

    if (!selectedCandidate) {
        alert('Please select a candidate.');
        return;
    }

    try {
        const response = await fetch('http://localhost:5000/vote', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ eventId, candidate: selectedCandidate })
        });
        const data = await response.json();
        if (data.success) {
            confetti({
                particleCount: 100,
                spread: 70,
                origin: { y: 0.6 }
            });
            alert('Vote cast successfully!');
            setTimeout(() => window.location.href = 'results.html?eventId=' + eventId, 2000);
        } else {
            alert('Voting failed: ' + data.message);
        }
    } catch (error) {
        console.error('Error:', error);
        alert('An error occurred while casting the vote.');
    }
}

async function loadResults(eventId) {
    try {
        const response = await fetch(`http://localhost:5000/results/${eventId}`);
        const data = await response.json();
        if (data.success) {
            document.getElementById('results-title').textContent = `Results: ${data.event.name}`;
            renderChart(data.results);
        } else {
            alert('Failed to load results: ' + data.message);
        }
    } catch (error) {
        console.error('Error:', error);
        alert('An error occurred while loading the results.');
    }
}

function logout() {
    localStorage.removeItem('userRole');
    window.location.href = 'login.html';
}